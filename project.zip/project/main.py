from py_scripts.database import *
from py_scripts.rename_table import *
from py_scripts.increment_transactions import *
from py_scripts.increment_terminals import *
from py_scripts.increment_fraud_oper import *
from py_scripts.increment_rep_fraud import *


config = get_config()
connection = get_connection(config)
cursor = connection.cursor()

create_and_set_schema(cursor, connection, "bank")

# remove_tables(cursor, connection)

# rename_cards(cursor, connection, "bank")
# rename_accounts(cursor, connection, "bank")
# rename_clients(cursor, connection, "bank")

csv2sql_transactions("transactions_03032021.txt", config)
xlsx2sql_terminals("terminals_03032021.xlsx", config)
xlsx2sql_passport_blacklist("passport_blacklist_03032021.xlsx", config)

create_dwh_fact_transactions(cursor, connection, "bank")
create_dwh_dim_terminals_hist(cursor, connection, "bank")
create_v_dwh_dim_terminals_hist(cursor, connection)
create_rep_fraud(cursor, connection, "bank")

stg_update_transactions(cursor, connection)
stg_new_transactions(cursor, connection)
update_dwh_fact_transactions(cursor, connection)


stg_new_terminals(cursor, connection)
stg_deleted_terminals(cursor, connection)
stg_updated_terminals(cursor, connection)
update_dwh_dim_terminals_hist(cursor, connection)


stg_oper_expired_passport(cursor, connection)
stg_invalid_contract(cursor, connection)
stg_oper_diff_cities(cursor, connection)

create_stg_rep_fraud(cursor, connection, "bank")
update_stg_rep_fraud(cursor, connection)
stg_new_rep_fraud(cursor, connection)

update_rep_fraud(cursor, connection)


close(connection, cursor)












