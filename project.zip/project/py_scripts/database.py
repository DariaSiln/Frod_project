import psycopg2
import json
import pandas as pd 
from sqlalchemy import create_engine
import os
import sqlalchemy 


def get_config(path = "db_config.json"):
	with open(path, "r") as f:
		config = json.load(f)
		return config 


def get_connection(config):
	connection = psycopg2.connect(**config)
	return connection


def close(connection=None, cursor=None):
	if cursor:
		cursor.close()

	if connection:
		connection.close()

def create_and_set_schema(cursor, connection, schema_name):
	cursor.execute(f"create schema if not exists {schema_name}")
	cursor.execute(f"set search_path to {schema_name}")

	connection.commit()


def csv2sql_transactions(path, c):
	connect_str = f"postgresql://{c['user']}:{c['password']}@{c['host']}:{c['port']}/{c['database']}"
	connection = create_engine(connect_str)
	df = pd.read_csv(path, sep = ';')
	df.to_sql(name="stg_transactions", con=connection, schema="bank", if_exists="replace", index=False, dtype = {'transaction_id': sqlalchemy.types.Text, 'transaction_date': sqlalchemy.types.DateTime})
	os.replace(path, f"archive/{path}.backup")

def xlsx2sql_terminals(path, c):
	connect_str = f"postgresql://{c['user']}:{c['password']}@{c['host']}:{c['port']}/{c['database']}"
	connection = create_engine(connect_str)
	df = pd.read_excel(path)
	df.to_sql(name="stg_terminals", con=connection, schema="bank", if_exists="replace", index=False)
	os.replace(path, f"archive/{path}.backup")


def xlsx2sql_passport_blacklist(path, c):
	connect_str = f"postgresql://{c['user']}:{c['password']}@{c['host']}:{c['port']}/{c['database']}"
	connection = create_engine(connect_str)
	df = pd.read_excel(path)
	df.to_sql(name="dwh_fact_passport_blacklist", con=connection, schema="bank", if_exists="replace", index=False, dtype = {'date': sqlalchemy.types.DateTime})
	os.replace(path, f"archive/{path}.backup")

def create_dwh_fact_transactions(cursor, connection, schema_name):
	cursor.execute("""
		CREATE TABLE if not exists dwh_fact_transactions(
			transaction_id varchar(128),
			transaction_date TIMESTAMP,
			amount decimal(7, 2),
			card_num varchar(20),
			oper_type varchar(128),
			oper_result varchar(128),
			terminal varchar(128),
			create_dt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
			update_dt TIMESTAMP
		)
	""")

	connection.commit()

def create_dwh_dim_terminals_hist(cursor, connection, schema_name):
	cursor.execute("""
		CREATE TABLE if not exists dwh_dim_terminals_hist(
			terminal_id varchar(128),
			terminal_type varchar(20),
			terminal_city varchar(128),
			terminal_address varchar(128),
			deleted_flg numeric(1) default 0,
			start_dttm TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
			end_dttm TIMESTAMP default '2999-12-31 23:59:59'
		)
	""")

	connection.commit()

def create_v_dwh_dim_terminals_hist(cursor, connection):
	cursor.execute("""
		DROP VIEW if exists v_dwh_dim_terminals_hist
	""")
	cursor.execute("""
		CREATE VIEW v_dwh_dim_terminals_hist as
		   SELECT
			terminal_id,
			terminal_type,
			terminal_city,
			terminal_address
		   FROM dwh_dim_terminals_hist
		   WHERE end_dttm = '2999-12-31 23:59:59'
		     AND deleted_flg = 0 
	""")

	connection.commit()

def create_rep_fraud(cursor, connection, schema_name):
	cursor.execute("""
		CREATE TABLE if not exists rep_fraud(
			event_dt date,
			passport varchar(128),
			last_name varchar(128),
			first_name varchar(128),
			phone varchar(128),
			event_type varchar(128),
			report_dt date
		)
	""")

	connection.commit()

def remove_tables(cursor, connection):
	cursor.execute("""
		DROP VIEW v_dwh_dim_terminals_hist;
	""")
	cursor.execute("""
		SELECT 
		   table_name
        FROM information_schema.tables
        WHERE table_schema = 'bank'
        AND table_name <> 'dwh_dim_clients'
        AND table_name <> 'dwh_dim_cards'
        AND table_name <> 'dwh_dim_accounts';
	""")
	for table in cursor.fetchall():
		cursor.execute(f"DROP TABLE if exists {table[0]}")

	connection.commit()