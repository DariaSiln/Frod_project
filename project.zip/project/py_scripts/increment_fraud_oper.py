def stg_oper_expired_passport(cursor, connection):
	cursor.execute("""
		DROP TABLE if exists stg_oper_expired_passport
	""")
	cursor.execute("""
		CREATE TABLE if not exists stg_oper_expired_passport as
           SELECT DISTINCT
              t1.transaction_date::date,
              t4.passport_num,
              t4.last_name,
              t4.first_name,
              t4.phone,
              'expired or blocked passport' as event_type
           FROM dwh_fact_transactions t1
           LEFT JOIN dwh_dim_cards t2
           ON t1.card_num = t2.card_num
           LEFT JOIN dwh_dim_accounts t3
           ON t2.account = t3.account
           LEFT JOIN dwh_dim_clients t4
           ON t3.client = t4.client_id
           LEFT JOIN dwh_fact_passport_blacklist t5
           ON t4.passport_num = t5.passport
           WHERE t4.passport_valid_to::date < t1.transaction_date::date
              OR t5.date <= t1.transaction_date::date
	""")

	connection.commit()



def stg_invalid_contract(cursor, connection):
	cursor.execute("""
		DROP TABLE if exists stg_invalid_contract
	""")
	cursor.execute("""
		CREATE TABLE if not exists stg_invalid_contract as
           SELECT DISTINCT
              t1.transaction_date::date,
              t4.passport_num,
              t4.last_name,
              t4.first_name,
              t4.phone,
              'invalid contract' as event_type
           FROM dwh_fact_transactions t1
           LEFT JOIN dwh_dim_cards t2
           ON t1.card_num = t2.card_num
           LEFT JOIN dwh_dim_accounts t3
           ON t2.account = t3.account
           LEFT JOIN dwh_dim_clients t4
           ON t3.client = t4.client_id
           WHERE t3.valid_to < t1.transaction_date::date
	""")

	connection.commit()




def stg_oper_diff_cities(cursor, connection):
	cursor.execute("""
		DROP TABLE if exists stg_oper_diff_cities
	""")
	cursor.execute("""
		CREATE TABLE if not exists stg_oper_diff_cities as
          SELECT DISTINCT
            t1.transaction_date::date,
            t4.passport_num,
            t4.last_name,
            t4.first_name,
            t4.phone,
            'oper diff cities' as event_type
          FROM dwh_fact_transactions t1
          LEFT JOIN dwh_dim_cards t2
          ON t1.card_num = t2.card_num
          LEFT JOIN dwh_dim_accounts t3
          ON t2.account = t3.account
          LEFT JOIN dwh_dim_clients t4
          ON t3.client = t4.client_id
          INNER JOIN (
            SELECT 
              transaction_date,
              account
            FROM (
             SELECT DISTINCT
                t1.transaction_date::date,
                extract (hour from t1.transaction_date::time) as hour,
                t3.account,
                t4.terminal_city
             FROM dwh_fact_transactions t1
             LEFT JOIN dwh_dim_cards t2
             ON t1.card_num = t2.card_num
             LEFT JOIN dwh_dim_accounts t3
             ON t2.account = t3.account
             LEFT JOIN v_dwh_dim_terminals_hist t4
             ON  t1.terminal = t4.terminal_id
             )
            GROUP BY transaction_date, hour, account
            HAVING count(terminal_city) > 1
            ) t5
           ON t2.account = t5.account
           AND t1.transaction_date::date = t5.transaction_date
	""")

	connection.commit()