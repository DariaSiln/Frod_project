def create_stg_rep_fraud(cursor, connection, schema_name):
	cursor.execute("""
		CREATE TABLE if not exists stg_rep_fraud(
			event_dt date,
			passport varchar(128),
			last_name varchar(128),
			first_name varchar(128),
			phone varchar(128),
			event_type varchar(128),
			report_dt date
		)
	""")

	connection.commit()


def update_stg_rep_fraud(cursor, connection):
	cursor.execute("""
		INSERT INTO stg_rep_fraud(
			event_dt,
			passport,
			last_name,
			first_name,
			phone,
			event_type
		)
		SELECT
			transaction_date,
			passport_num,
			last_name,
			first_name,
			phone,
			event_type
		FROM stg_oper_expired_passport
	""")
	cursor.execute("""
		INSERT INTO stg_rep_fraud(
			event_dt,
			passport,
			last_name,
			first_name,
			phone,
			event_type
		)
		SELECT
			transaction_date,
			passport_num,
			last_name,
			first_name,
			phone,
			event_type
		FROM stg_invalid_contract
	""")
	cursor.execute("""
		INSERT INTO stg_rep_fraud(
			event_dt,
			passport,
			last_name,
			first_name,
			phone,
			event_type
		)
		SELECT
			transaction_date,
			passport_num,
			last_name,
			first_name,
			phone,
			event_type
		FROM stg_oper_diff_cities
	""")
	cursor.execute("""
		UPDATE stg_rep_fraud
		SET report_dt = NOW()
	""")

	connection.commit()



def stg_new_rep_fraud(cursor, connection):
	cursor.execute("""
		DROP TABLE if exists stg_new_rep_fraud
	""")
	cursor.execute("""
		CREATE TABLE if not exists stg_new_rep_fraud as
		   SELECT
			t1.event_dt,
			t1.passport,
			t1.last_name,
			t1.first_name,
			t1.phone,
			t1.event_type,
			t1.report_dt
           FROM stg_rep_fraud t1
           LEFT JOIN rep_fraud t2
           ON t1.event_dt = t2.event_dt
           AND t1.passport = t2.passport
           WHERE t2.passport is null
	""")

	connection.commit()



def update_rep_fraud(cursor, connection):
	cursor.execute("""
		INSERT INTO rep_fraud(
			event_dt,
			passport,
			last_name,
			first_name,
			phone,
			event_type,
			report_dt
		)
		SELECT
			event_dt,
			passport,
			last_name,
			first_name,
			phone,
			event_type,
			report_dt
		FROM stg_new_rep_fraud
	""")

	connection.commit()


