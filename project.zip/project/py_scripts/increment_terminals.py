def stg_new_terminals(cursor, connection):
	cursor.execute("""
		DROP TABLE if exists stg_new_terminals
	""")
	cursor.execute("""
		CREATE TABLE if not exists stg_new_terminals as
		   SELECT
			t1.terminal_id,
			t1.terminal_type,
			t1.terminal_city,
			t1.terminal_address
           FROM stg_terminals t1
           LEFT JOIN v_dwh_dim_terminals_hist t2
           ON t1.terminal_id = t2.terminal_id
           WHERE t2.terminal_id is null
	""")

	connection.commit()



def stg_deleted_terminals(cursor, connection):
	cursor.execute("""
		DROP TABLE if exists stg_deleted_terminals
	""")
	cursor.execute("""
		CREATE TABLE if not exists stg_deleted_terminals as
		   SELECT
			t1.terminal_id,
			t1.terminal_type,
			t1.terminal_city,
			t1.terminal_address
           FROM v_dwh_dim_terminals_hist t1
           LEFT JOIN stg_terminals t2
           ON t1.terminal_id = t2.terminal_id
           WHERE t2.terminal_id is null
	""")
	
	connection.commit()



def stg_updated_terminals(cursor, connection):
	cursor.execute("""
		DROP TABLE if exists stg_updated_terminals
	""")
	cursor.execute("""
		CREATE TABLE if not exists stg_updated_terminals as
		  SELECT 
			t2.terminal_id,
			t2.terminal_type,
			t2.terminal_city,
			t2.terminal_address
          FROM v_dwh_dim_terminals_hist t1
          INNER JOIN stg_terminals t2
          ON t1.terminal_id = t2.terminal_id
          WHERE t1.terminal_type <> t2.terminal_type
			OR t1.terminal_city <> t2.terminal_city
			OR t1.terminal_address <> t2.terminal_address
	""")
	
	connection.commit()



def update_dwh_dim_terminals_hist(cursor, connection):
	cursor.execute("""
		INSERT INTO dwh_dim_terminals_hist(
			terminal_id,
			terminal_type,
			terminal_city,
			terminal_address
		)
		SELECT
			terminal_id,
			terminal_type,
			terminal_city,
			terminal_address
		FROM stg_new_terminals
	""")
	cursor.execute("""
		UPDATE dwh_dim_terminals_hist
		SET end_dttm = NOW() - INTERVAL '1 second'
		WHERE terminal_id in (
			SELECT
			  terminal_id
			FROM stg_updated_terminals
			)
		AND end_dttm = '2999-12-31 23:59:59'
	""")
	cursor.execute("""
		INSERT INTO dwh_dim_terminals_hist(
			terminal_id,
			terminal_type,
			terminal_city,
			terminal_address
		)
		SELECT
			terminal_id,
			terminal_type,
			terminal_city,
			terminal_address
		FROM stg_updated_terminals
	""")
	cursor.execute("""
		UPDATE dwh_dim_terminals_hist
		SET end_dttm = NOW() - INTERVAL '1 second'
		WHERE terminal_id in (
			SELECT
			  terminal_id
			FROM stg_deleted_terminals
			)
		AND end_dttm = '2999-12-31 23:59:59'
	""")
	cursor.execute("""
		INSERT INTO dwh_dim_terminals_hist(
			terminal_id,
			terminal_type,
			terminal_city,
			terminal_address,
			deleted_flg
		)
		SELECT
			terminal_id,
			terminal_type,
			terminal_city,
			terminal_address,
			1
		FROM stg_deleted_terminals
	""")

	connection.commit()