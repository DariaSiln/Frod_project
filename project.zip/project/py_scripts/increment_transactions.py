def stg_update_transactions(cursor, connection):
	cursor.execute("""
		UPDATE stg_transactions 
        SET amount = replace(amount,',' , '.')
	""")
	cursor.execute("""
		ALTER TABLE stg_transactions ALTER COLUMN amount type decimal(7, 2) USING (amount::decimal(7, 2))
	""")

	connection.commit()



def stg_new_transactions(cursor, connection):
	cursor.execute("""
		DROP TABLE if exists stg_new_transactions
	""")
	cursor.execute("""
		CREATE TABLE if not exists stg_new_transactions as
		   SELECT
			t1.transaction_id,
			t1.transaction_date,
			t1.amount,
			t1.card_num,
			t1.oper_type,
			t1.oper_result,
			t1.terminal
           FROM stg_transactions t1
           LEFT JOIN dwh_fact_transactions t2
           ON t1.transaction_id = t2.transaction_id
           WHERE t2.transaction_id is null
	""")

	connection.commit()




def update_dwh_fact_transactions(cursor, connection):
	cursor.execute("""
		INSERT INTO dwh_fact_transactions(
			transaction_id,
			transaction_date,
			amount,
			card_num,
			oper_type,
			oper_result,
			terminal
		)
		SELECT
			transaction_id,
			transaction_date,
			amount,
			card_num,
			oper_type,
			oper_result,
			terminal
		FROM stg_new_transactions
	""")
	cursor.execute("""
		UPDATE dwh_fact_transactions
		SET update_dt = NOW()
	""")

	connection.commit()

