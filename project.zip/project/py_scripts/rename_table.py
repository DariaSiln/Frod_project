def rename_cards(cursor, connection, schema_name):
	cursor.execute("""
        ALTER TABLE cards RENAME TO dwh_dim_cards;
	""")

	connection.commit()


def rename_accounts(cursor, connection, schema_name):
	cursor.execute("""
        ALTER TABLE accounts RENAME TO dwh_dim_accounts;
	""")

	connection.commit()


def rename_clients(cursor, connection, schema_name):
	cursor.execute("""
        ALTER TABLE clients RENAME TO dwh_dim_clients;
	""")

	connection.commit()